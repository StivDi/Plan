﻿using System;
using System.Linq;
using Empleado.Modelo;


namespace Empleado
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Buen dìa,");
            Console.WriteLine("A continuacion encontrarà: Cedula, Nombre, Salario y Vacaciones en dias");
            ListEmpleado();
        
        }

        static void ListEmpleado()

        {

            var db = new EmpleadoContext();
            var Empleados = db.Empleado.ToList();

            foreach (var myEmpleado in Empleados)

            {
                Console.WriteLine($" (myEmpleado.Cedula)\t (myEmpleado.Nombre) \t (myEmpleado.Salario) \t (myEmpleado.Vacaciones) \t ");
            }

            Console.ReadKey();
        }
    }
}