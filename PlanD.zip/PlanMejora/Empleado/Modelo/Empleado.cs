﻿using System;
using System.Collections.Generic;

namespace Empleado.Modelo
{
    public partial class Empleado
    {
        public int Cedula { get; set; }
        public string Nombre { get; set; }
        public int? Salario { get; set; }
        public int? Vacaciones { get; set; }
    }
}
