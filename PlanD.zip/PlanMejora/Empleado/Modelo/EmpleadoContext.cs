﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace Empleado.Modelo
{
    public partial class EmpleadoContext : DbContext
    {
        public virtual DbSet<Empleado> Empleado { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseMySql("Server=localhost; userid=root; password= ; Database=Empleado");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Empleado>(entity =>
            {
                entity.HasKey(e => e.Cedula);

                entity.ToTable("empleado");

                entity.Property(e => e.Cedula)
                    .HasColumnName("cedula")
                    .HasColumnType("int(11)");

                entity.Property(e => e.Nombre)
                    .IsRequired()
                    .HasColumnName("nombre")
                    .HasMaxLength(20);

                entity.Property(e => e.Salario)
                    .HasColumnName("salario")
                    .HasColumnType("int(11)");

                entity.Property(e => e.Vacaciones)
                    .HasColumnName("vacaciones")
                    .HasColumnType("int(11)");
            });
        }
    }
}
